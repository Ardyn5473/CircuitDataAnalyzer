RCNX内部のSQLiteテーブルをCSV化したものです。
CSVはUTF-8 BOM付きです。
_extractedフォルダには変換元の展開データを残しています。
