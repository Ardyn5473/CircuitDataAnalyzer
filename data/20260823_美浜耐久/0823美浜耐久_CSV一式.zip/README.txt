0823美浜耐久.rcnx CSV展開

RCNX内部のSQLiteデータをCSV化したものです。
WayPoints: 190,558点
Lap: 220件
Split: 220件

主なWayPoints列:
id, rcr, time, ms, lat, lon, altitude, heading, speed, Gx, Gy, Gz, distance, AccDec, Inclination, tilt, lean
datetime_JST は time + ms から作成した日本時間の表示用列です。

注意:
・speed はデータ値から km/h と考えるのが自然ですが、RCNX仕様書を参照していないため確定表記はしていません。
・distance はラップ表の値から km と考えるのが自然です。
・Gx/Gy/Gz はG値と考えられます。
・tilt/lean は内部表現の可能性があるため、生データをそのまま保存しています。
